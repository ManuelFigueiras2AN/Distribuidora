﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    //Los fabricantes poseen CUIT, nombre de fantasía, dirección, teléfono, email, Persona de contacto, localidad y provincia.
    public class Fabricante
    {
        public int FabricanteId { get; set; }
        public long Cuit {  get; set; }
        public string Nombre { get; set; }
        public string Direccion {  get; set; }
        public long Telefono { get; set; }
        public string Correo { get; set; }
        public string PersonaContacto { get; set; }
        public string Localidad { get; set; }
        public string Provincia { get; set; }

        public List<Producto> Productos { get; set; }


        public bool AgregarProducto(Producto producto)
        {
            try
            {
                var productoBuscado=Productos.FirstOrDefault(p=>p.Codigo == producto.Codigo);
                if (productoBuscado == null)
                {
                    Productos.Add(producto);
                    return true;
                }
                else return false;
            }
            catch(Exception ex)
            {
                return false;
            }
        }
        public bool EliminarProducto(Producto producto)
        {
            try
            {
                var productoBuscado = Productos.FirstOrDefault(p => p.Codigo == producto.Codigo);
                if (productoBuscado != null)
                {
                    Productos.Remove(producto);
                    return true;
                }
                else return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
