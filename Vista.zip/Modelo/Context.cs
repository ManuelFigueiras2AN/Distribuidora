﻿using Microsoft.EntityFrameworkCore;

namespace Modelo
{
    public class Context:DbContext
    {
        public DbSet<Categoria> Categorias { get; set; }
        public DbSet<Producto> Productos { get; set; }
        public DbSet<Fabricante> Fabricantes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder options) 
        
            =>options.UseSqlServer($"Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog= Distribuidora ;Integrated Security=True;Persist Security Info=False;Pooling=False;Multiple Active Result Sets=False;Encrypt=False;Trust Server Certificate=False;Command Timeout=0");

        protected override void OnModelCreating(ModelBuilder model)
        {
            model.Entity<Producto>().ToTable("Productos").HasKey( p => p.ProductoId);
            model.Entity<Fabricante>().ToTable("Fabricantes").HasKey( f => f.FabricanteId);
            model.Entity<Categoria>().ToTable("Categorias").HasKey( c => c.CategoriaId);
            model.Entity<Fabricante>().HasMany(fp => fp.Productos).WithMany();
        }
    }
}
