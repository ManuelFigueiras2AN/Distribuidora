﻿namespace Vista
{
    partial class Menu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_Productos = new Button();
            btn_Categorias = new Button();
            btn_Fabricantes = new Button();
            SuspendLayout();
            // 
            // btn_Productos
            // 
            btn_Productos.BackColor = SystemColors.Info;
            btn_Productos.FlatAppearance.BorderColor = Color.Yellow;
            btn_Productos.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold | FontStyle.Italic);
            btn_Productos.Location = new Point(144, 63);
            btn_Productos.Name = "btn_Productos";
            btn_Productos.Size = new Size(208, 57);
            btn_Productos.TabIndex = 0;
            btn_Productos.Text = "Gestión Productos";
            btn_Productos.UseVisualStyleBackColor = false;
            btn_Productos.Click += btn_Productos_Click;
            // 
            // btn_Categorias
            // 
            btn_Categorias.BackColor = SystemColors.Info;
            btn_Categorias.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold | FontStyle.Italic);
            btn_Categorias.Location = new Point(144, 127);
            btn_Categorias.Name = "btn_Categorias";
            btn_Categorias.Size = new Size(208, 57);
            btn_Categorias.TabIndex = 1;
            btn_Categorias.Text = "Gestion Categorias";
            btn_Categorias.UseVisualStyleBackColor = false;
            // 
            // btn_Fabricantes
            // 
            btn_Fabricantes.BackColor = SystemColors.Info;
            btn_Fabricantes.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold | FontStyle.Italic);
            btn_Fabricantes.Location = new Point(144, 191);
            btn_Fabricantes.Name = "btn_Fabricantes";
            btn_Fabricantes.Size = new Size(208, 56);
            btn_Fabricantes.TabIndex = 2;
            btn_Fabricantes.Text = "Gestión Fabricantes";
            btn_Fabricantes.UseVisualStyleBackColor = false;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Highlight;
            ClientSize = new Size(494, 313);
            Controls.Add(btn_Fabricantes);
            Controls.Add(btn_Categorias);
            Controls.Add(btn_Productos);
            Name = "Menu";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btn_Productos;
        private Button btn_Categorias;
        private Button btn_Fabricantes;
    }
}
