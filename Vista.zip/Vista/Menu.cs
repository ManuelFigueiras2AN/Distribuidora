namespace Vista
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void btn_Productos_Click(object sender, EventArgs e)
        {

        }
    }
}
