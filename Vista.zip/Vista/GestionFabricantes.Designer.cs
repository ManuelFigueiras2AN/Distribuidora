﻿namespace Vista
{
    partial class GestionFabricantes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            ChkList_Productos = new CheckedListBox();
            txt_PersonaContacto = new TextBox();
            txt_Telefono = new TextBox();
            txt_Correo = new TextBox();
            txt_Provincia = new TextBox();
            txt_Localidad = new TextBox();
            textBox3 = new TextBox();
            txt_Nombre = new TextBox();
            txt_Cuit = new TextBox();
            lbl_Productos = new Label();
            lbl_Contacto = new Label();
            lbl_Telefono = new Label();
            lbl_Correo = new Label();
            lbl_Provincia = new Label();
            lbl_Localidad = new Label();
            txt_Direccion = new Label();
            lbl_Nombre = new Label();
            lbl_Cuit = new Label();
            dgv_Fabricantes = new DataGridView();
            btn_CargarFabricante = new Button();
            btn_EliminarFabricante = new Button();
            btn_EditarFabricante = new Button();
            btn_Volver = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_Fabricantes).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btn_Volver);
            groupBox1.Controls.Add(btn_EditarFabricante);
            groupBox1.Controls.Add(btn_EliminarFabricante);
            groupBox1.Controls.Add(btn_CargarFabricante);
            groupBox1.Controls.Add(ChkList_Productos);
            groupBox1.Controls.Add(txt_PersonaContacto);
            groupBox1.Controls.Add(txt_Telefono);
            groupBox1.Controls.Add(txt_Correo);
            groupBox1.Controls.Add(txt_Provincia);
            groupBox1.Controls.Add(txt_Localidad);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(txt_Nombre);
            groupBox1.Controls.Add(txt_Cuit);
            groupBox1.Controls.Add(lbl_Productos);
            groupBox1.Controls.Add(lbl_Contacto);
            groupBox1.Controls.Add(lbl_Telefono);
            groupBox1.Controls.Add(lbl_Correo);
            groupBox1.Controls.Add(lbl_Provincia);
            groupBox1.Controls.Add(lbl_Localidad);
            groupBox1.Controls.Add(txt_Direccion);
            groupBox1.Controls.Add(lbl_Nombre);
            groupBox1.Controls.Add(lbl_Cuit);
            groupBox1.Location = new Point(12, 1);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(776, 177);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // ChkList_Productos
            // 
            ChkList_Productos.FormattingEnabled = true;
            ChkList_Productos.Location = new Point(584, 46);
            ChkList_Productos.Name = "ChkList_Productos";
            ChkList_Productos.Size = new Size(148, 112);
            ChkList_Productos.TabIndex = 17;
            // 
            // txt_PersonaContacto
            // 
            txt_PersonaContacto.Location = new Point(450, 90);
            txt_PersonaContacto.Name = "txt_PersonaContacto";
            txt_PersonaContacto.Size = new Size(119, 23);
            txt_PersonaContacto.TabIndex = 16;
            // 
            // txt_Telefono
            // 
            txt_Telefono.Location = new Point(305, 91);
            txt_Telefono.Name = "txt_Telefono";
            txt_Telefono.Size = new Size(123, 23);
            txt_Telefono.TabIndex = 15;
            // 
            // txt_Correo
            // 
            txt_Correo.Location = new Point(164, 91);
            txt_Correo.Name = "txt_Correo";
            txt_Correo.Size = new Size(119, 23);
            txt_Correo.TabIndex = 14;
            // 
            // txt_Provincia
            // 
            txt_Provincia.Location = new Point(19, 90);
            txt_Provincia.Name = "txt_Provincia";
            txt_Provincia.Size = new Size(126, 23);
            txt_Provincia.TabIndex = 13;
            // 
            // txt_Localidad
            // 
            txt_Localidad.Location = new Point(450, 42);
            txt_Localidad.Name = "txt_Localidad";
            txt_Localidad.Size = new Size(119, 23);
            txt_Localidad.TabIndex = 12;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(305, 42);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(126, 23);
            textBox3.TabIndex = 11;
            // 
            // txt_Nombre
            // 
            txt_Nombre.Location = new Point(164, 42);
            txt_Nombre.Name = "txt_Nombre";
            txt_Nombre.Size = new Size(119, 23);
            txt_Nombre.TabIndex = 10;
            // 
            // txt_Cuit
            // 
            txt_Cuit.Location = new Point(19, 42);
            txt_Cuit.Name = "txt_Cuit";
            txt_Cuit.Size = new Size(126, 23);
            txt_Cuit.TabIndex = 9;
            // 
            // lbl_Productos
            // 
            lbl_Productos.AutoSize = true;
            lbl_Productos.Location = new Point(584, 28);
            lbl_Productos.Name = "lbl_Productos";
            lbl_Productos.Size = new Size(61, 15);
            lbl_Productos.TabIndex = 8;
            lbl_Productos.Text = "Productos";
            // 
            // lbl_Contacto
            // 
            lbl_Contacto.AutoSize = true;
            lbl_Contacto.Location = new Point(450, 76);
            lbl_Contacto.Name = "lbl_Contacto";
            lbl_Contacto.Size = new Size(101, 15);
            lbl_Contacto.TabIndex = 7;
            lbl_Contacto.Text = "Persona Contacto";
            // 
            // lbl_Telefono
            // 
            lbl_Telefono.AutoSize = true;
            lbl_Telefono.Location = new Point(308, 76);
            lbl_Telefono.Name = "lbl_Telefono";
            lbl_Telefono.Size = new Size(52, 15);
            lbl_Telefono.TabIndex = 6;
            lbl_Telefono.Text = "Telefono";
            // 
            // lbl_Correo
            // 
            lbl_Correo.AutoSize = true;
            lbl_Correo.Location = new Point(164, 77);
            lbl_Correo.Name = "lbl_Correo";
            lbl_Correo.Size = new Size(105, 15);
            lbl_Correo.TabIndex = 5;
            lbl_Correo.Text = "Correo Electronico";
            // 
            // lbl_Provincia
            // 
            lbl_Provincia.AutoSize = true;
            lbl_Provincia.Location = new Point(22, 76);
            lbl_Provincia.Name = "lbl_Provincia";
            lbl_Provincia.Size = new Size(56, 15);
            lbl_Provincia.TabIndex = 4;
            lbl_Provincia.Text = "Provincia";
            // 
            // lbl_Localidad
            // 
            lbl_Localidad.AutoSize = true;
            lbl_Localidad.Location = new Point(450, 28);
            lbl_Localidad.Name = "lbl_Localidad";
            lbl_Localidad.Size = new Size(58, 15);
            lbl_Localidad.TabIndex = 3;
            lbl_Localidad.Text = "Localidad";
            // 
            // txt_Direccion
            // 
            txt_Direccion.AutoSize = true;
            txt_Direccion.Location = new Point(305, 28);
            txt_Direccion.Name = "txt_Direccion";
            txt_Direccion.Size = new Size(57, 15);
            txt_Direccion.TabIndex = 2;
            txt_Direccion.Text = "Dirección";
            // 
            // lbl_Nombre
            // 
            lbl_Nombre.AutoSize = true;
            lbl_Nombre.Location = new Point(164, 28);
            lbl_Nombre.Name = "lbl_Nombre";
            lbl_Nombre.Size = new Size(51, 15);
            lbl_Nombre.TabIndex = 1;
            lbl_Nombre.Text = "Nombre";
            // 
            // lbl_Cuit
            // 
            lbl_Cuit.AutoSize = true;
            lbl_Cuit.Location = new Point(19, 26);
            lbl_Cuit.Name = "lbl_Cuit";
            lbl_Cuit.Size = new Size(29, 15);
            lbl_Cuit.TabIndex = 0;
            lbl_Cuit.Text = "Cuit";
            // 
            // dgv_Fabricantes
            // 
            dgv_Fabricantes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Fabricantes.Location = new Point(12, 184);
            dgv_Fabricantes.Name = "dgv_Fabricantes";
            dgv_Fabricantes.Size = new Size(776, 231);
            dgv_Fabricantes.TabIndex = 1;
            // 
            // btn_CargarFabricante
            // 
            btn_CargarFabricante.Location = new Point(19, 135);
            btn_CargarFabricante.Name = "btn_CargarFabricante";
            btn_CargarFabricante.Size = new Size(126, 33);
            btn_CargarFabricante.TabIndex = 18;
            btn_CargarFabricante.Text = "Cargar Fabricante";
            btn_CargarFabricante.UseVisualStyleBackColor = true;
            // 
            // btn_EliminarFabricante
            // 
            btn_EliminarFabricante.Location = new Point(165, 135);
            btn_EliminarFabricante.Name = "btn_EliminarFabricante";
            btn_EliminarFabricante.Size = new Size(118, 33);
            btn_EliminarFabricante.TabIndex = 19;
            btn_EliminarFabricante.Text = "Eliminar Fabricante";
            btn_EliminarFabricante.UseVisualStyleBackColor = true;
            // 
            // btn_EditarFabricante
            // 
            btn_EditarFabricante.Location = new Point(305, 135);
            btn_EditarFabricante.Name = "btn_EditarFabricante";
            btn_EditarFabricante.Size = new Size(123, 33);
            btn_EditarFabricante.TabIndex = 20;
            btn_EditarFabricante.Text = "Modificar Datos";
            btn_EditarFabricante.UseVisualStyleBackColor = true;
            // 
            // btn_Volver
            // 
            btn_Volver.Location = new Point(460, 135);
            btn_Volver.Name = "btn_Volver";
            btn_Volver.Size = new Size(109, 33);
            btn_Volver.TabIndex = 21;
            btn_Volver.Text = "Volver";
            btn_Volver.UseVisualStyleBackColor = true;
            // 
            // GestionFabricantes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgv_Fabricantes);
            Controls.Add(groupBox1);
            Name = "GestionFabricantes";
            Text = "GestionFabricantes";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_Fabricantes).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label lbl_Productos;
        private Label lbl_Contacto;
        private Label lbl_Telefono;
        private Label lbl_Correo;
        private Label lbl_Provincia;
        private Label lbl_Localidad;
        private Label txt_Direccion;
        private Label lbl_Nombre;
        private Label lbl_Cuit;
        private DataGridView dgv_Fabricantes;
        private TextBox txt_PersonaContacto;
        private TextBox txt_Telefono;
        private TextBox txt_Correo;
        private TextBox txt_Provincia;
        private TextBox txt_Localidad;
        private TextBox textBox3;
        private TextBox txt_Nombre;
        private TextBox txt_Cuit;
        private CheckedListBox ChkList_Productos;
        private Button btn_EliminarFabricante;
        private Button btn_CargarFabricante;
        private Button btn_Volver;
        private Button btn_EditarFabricante;
    }
}