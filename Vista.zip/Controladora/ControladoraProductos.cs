﻿using Modelo;

namespace Controladora
{
    
    public class ControladoraProductos
    {
        Context _context;

        private ControladoraProductos()
        {
            _context = new Context();
        }

        public bool AgregarProducto(Producto producto)
        {
            try 
            {
                var buscarProducto = _context.Productos.FirstOrDefault(p => p.Codigo == producto.Codigo);
                if (buscarProducto == null)
                {
                    _context.Productos.Add(producto);
                    return _context.SaveChanges()>0;
                }
                else return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool EliminarProducto(Producto producto)
        {
            try
            {
                var buscarProducto = _context.Productos.FirstOrDefault(p => p.Codigo == producto.Codigo);
                if (buscarProducto != null)
                {
                    _context.Productos.Remove(producto);
                    return _context.SaveChanges() > 0;
                }
                else return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool ModificarProducto(Producto producto)
        {
            try
            {
                var buscarProducto = _context.Productos.FirstOrDefault(p => p.Codigo == producto.Codigo);
                if (buscarProducto == null)
                {
                    _context.Productos.Update(producto);
                    return _context.SaveChanges() > 0;
                }
                else return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
