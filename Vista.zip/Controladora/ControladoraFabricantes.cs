﻿using Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controladora
{
    public class ControladoraFabricantes
    {
        Context _context;

        private ControladoraFabricantes() 
        {
            _context = new Context();
        }

        public bool AgregarFabricante(Fabricante fabricante)
        {
            try
            {
                var buscarFabricante = _context.Fabricantes.FirstOrDefault(f => f.Cuit == fabricante.Cuit);
                if (buscarFabricante == null)
                {
                    _context.Fabricantes.Add(fabricante);
                    return _context.SaveChanges() > 0;
                }
                else return false;
            }

            catch (Exception ex)
            {
                return false;
            }
        }

        public bool EliminarFabricante(Fabricante fabricante)
        {
            try
            {
                var buscarFabricante = _context.Fabricantes.FirstOrDefault(f => f.Cuit == fabricante.Cuit);
                if (buscarFabricante != null)
                {
                    _context.Fabricantes.Remove(fabricante);
                    return _context.SaveChanges() > 0;
                }
                else return false;
            }

            catch (Exception ex)
            {
                return false;
            }
        }

        public bool ModificarFabricante(Fabricante fabricante)
        {
            try
            {
                var buscarFabricante = _context.Fabricantes.FirstOrDefault(f => f.Cuit == fabricante.Cuit);
                if (buscarFabricante == null)
                {
                    _context.Fabricantes.Update(fabricante);
                    return _context.SaveChanges() > 0;
                }
                else return false;
            }

            catch (Exception ex)
            {
                return false;
            }
        }

        public List<Fabricante> RecuperarFabricantes() 
        {
            return _context.Fabricantes.ToList();
        }
    }
}
