﻿using Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controladora
{
    
    public class ControladoraCategorias
    {
        Context _context;

        private ControladoraCategorias() 
        {
            _context = new Context();
        }

        public bool AgregarCategoria(Categoria categoria)
        {
            try
            {
                var buscarCategoria = _context.Categorias.FirstOrDefault(c => c.Nombre == categoria.Nombre);
                if (buscarCategoria == null)
                {
                    _context.Categorias.Add(categoria);

                    return _context.SaveChanges() > 0;
                }
                else return false;

            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool EliminarCategoria(Categoria categoria)
        {
            try
            {
                var buscarCategoria = _context.Categorias.FirstOrDefault(c => c.Nombre == categoria.Nombre);

                if (buscarCategoria != null)
                {
                    _context.Remove(categoria);
                    return _context.SaveChanges() > 0;
                }
                else return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool MoficarCategoria(Categoria categoria)
        {
            try
            {
                var buscarCategoria = _context.Categorias.FirstOrDefault(c => c.Nombre == categoria.Nombre);

                if (buscarCategoria == null)
                {
                    _context.Update(categoria);
                    return _context.SaveChanges() > 0;
                }
                else return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
